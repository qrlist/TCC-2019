<?php
	require __DIR__.'/cabecalho_geral.php';
?>
<body>	

        <div class="ui mobile reversed equal width grid footerM">
          <div class="column footerM"></div>
          <div class="column footerM">

            <div class="marginCadM">
                <h1>
                    <div class="ui horizontal divider">
                        Cadastro de produto
                    </div>
                </h1>
            </div>

            <form class="ui large form" method="post" action="../controllers/mercado.php?acao=marcado_cadastro">
			  <div class="ui stacked segment">

                 <div class="fields">

                        <div class="ten wide field">
                            <label>Nome do Produto</label>
                  			<input type="text" placeholder="Ex.: Margarina Qualy">
                		</div>

                        <div class="six wide field">
                           <label>Peso Liquido</label>
                        <input type="text" placeholder="500g">
                        </div>

                    </div>

                <div class="fields">

                        <div class="eight wide field">
                            <label>Preço</label>
                  			<input type="text" placeholder="5,45">
                		</div>

                        <div class="eight wide field">
                           <label>Quantidade em Estoque</label>
                        <input name="email" id="email" type="text" placeholder="3" required>
                        </div>

                    </div>

                <div class="field">
                  <label>Marca do Produto</label>
                  <input type="text" placeholder="Qualy">
                </div>

                <div class="field">
                  <label>Descrição do Produto</label>
                  <input type="text" placeholder="Cremosa...">
                </div>

				  <div class="field">
                        <label>Foto do Produto</label>
                        <input type="file" value="Escolha uma imagem" />
                  </div>

				<div class="ui fluid large teal submit button bg_secundario">Cadastrar</div>
			  </div>

			</form>
          </div>
          <div class="column footerM"></div>
        </div>


</div>
</div>
</div>
</body>
<?php require __DIR__.'/footer.php';  ?>