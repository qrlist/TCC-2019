<?php

class Mercado{

    //ATRIBUTOS DA CLASSE
    public $nome_mercado;
    public $senha_mercado;
    public $cnpj;
    public $ie;
    public $email_mercado;
    public $telefone_mercado;
    public $foto_mercado;
    public $rua;
    public $numero;
    public $cep;
    public $tipoMercado;

    public $conexao_mercado;


    //COMPORTAMENTOS
    public function __construct(){
        $this->$tipoMercado = 3;
        $conexao_objeto = new Connection();
        $this->conexao_mercado = $conexao_objeto->conectar();
    }

    public function salvar_mercado($nome_mercado, $senha_mercado, $cnpj, $ie, $email_mercado, $telefone_mercado, $foto_mercado, $rua, $numero, $cep){
        $sql_mercado = "insert into mercado(nome_mercado, senha_mercado, cnpj, ie, email_mercado, telefone_mercado, foto_mercado) values ('{$nome_mercado}', '{$senha_mercado}', '{$cnpj}', '{$ie}', '{$email_mercado}', '{$telefone_mercado}', '{$foto_mercado}')";
        $resultado_mercado = $this->conexao_mercado->exec($sql_mercado);

        $sql_mercado_endereco = "insert into endereco(rua, numero, cep) values ('{$rua}', '{$numero}', {$cep})";
        $resultado_mercado_endereco = $this->conexao_mercado->exec($sql_mercado_endereco);

        $dados_mercado['dados'] = $resultado_mercado;
        $dados_mercado['endereco'] = $resultado_mercado_endereco;
    }

//    public function delete($cpf){
//        $sql_delete = "delete from usuario where cpf = '{$cpf}'";
//        $this->conexao_usuario->exec($sql_delete);
//    }

}