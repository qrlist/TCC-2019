	<?php
session_start();
include "cabecalho_geral.php";
require __DIR__.'/../controllers/usuario.php';
if (isset($_SESSION['logado']) and $_SESSION['logado'] =='sim'){
?>
<script>

   $(document).ready(function () {
   		$( ".troca" ).click(function(e) {
   			var id = e.target.id;
   			var value = $("#input"+id).val();
  			$('#'+id).toggleClass('green');
  			var texto = $("#"+id).text();
  			if (texto=="Adicionar") {
  				$('#'+id).text('Adicionado')
  				$("#input"+id).val(1);
  			}else{
  				$('#'+id).text('Adicionar')
  				$("#input"+id).val(0);
  			}
		});


   	})

</script>

<form method="post" action="../	controllers/lista.php?acao=salvar_lista">
	<div class="ui width grid">
		<div class="one wide column "></div>
		<div class="fourteen wide column">

			<div class="margin criarNovaLista">
				<center><h1>Criando Nova Lista</h1>
					<p>Dê um nome a sua lista</p>
					<div class="ui input">
						<input type="text" placeholder="Nome da lista" name="nome_lista" required="Por favor coloque o nome da sua lista">
					</div>
					<p></p>
					<p>Selecione todos os produtos que você deseja adicionar a lista, clicando no botão depois salve-a clicando em "Finalizar".</p></center>
				</div>

				<div class=" margin">
					<div class="ui horizontal divider"> 
						adicione produtos
					</div>
				</div>

				<div class="filtro">
					<div class="ui search centro">
						<div class="ui icon input">
							<input class="prompt" type="text" placeholder="Pesquisar">
							<i class="search icon"></i>
						</div>

						<div class="ui floating labeled icon dropdown button drop direita">
							<i class="filter icon"></i>
							<span class="text">Filter</span>
							<div class="menu">
								<div class="header">
									<i class="tags icon"></i>
									Filtro
								</div>
								<div class="item">Todos os mercados</div>
								<div class="item">Mercado 1</div>
								<div class="item">Mercado 2</div>
							</div>
						</div>
					</div>			
				</div>

				<div class="conteudoNovaLista">
				<div class="cardProduto">
				<?php 

              $conexaos = new Connection();
              $recebeConexao = $conexaos->conectar();
              $sql_produtos = "select distinct nome_produto,foto_produto,preco_prod,cod_produto,marca,nome_cat,desc_prod, peso_liq,cnpj_prod,nome_mercado from produtos,mercado,categoria_prod where cnpj_prod = cnpj and cod_cat_cod = cod_cat";
              $produto = $recebeConexao->query($sql_produtos)->fetchAll(PDO::FETCH_ASSOC);
             // var_dump($produto);

              foreach ($produto as $key => $value) {
    	        $cod_prod = $value['cod_produto'];
				echo '
						<div class="ui card">
							<div class="content">
								<div class="header">'.$value['nome_produto'].'</div>
							</div>
							<div class="content">
								<h4 class="ui sub header">categoria: '.$value['nome_cat'].'</h4>
								<br>
								<img class="img_mercado" src="../../imagens/foto_produto/'.$value['foto_produto'].'">
								<p></p>
								<p class="ui sub header right floated">Preço: R$'.$value['preco_prod'].'</p>
								<p class="ui sub header">Peso: '.$value['peso_liq'].'</p>
								<p class="ui sub header">Marca: '.$value['marca'].'</p>
								<p class="ui sub header">Mercado: '.$value['nome_mercado'].'</p>
								<p class="ui sub header">Descrição: '.$value['desc_prod'].'</p>
								<div class="eight wide field">
								<input type="number" class="" name="qtd_item_'.$cod_prod.'" value="1" max = "100" min="1" required title="Escolha uma quantidade de produtos que deseja" /> 
								</div>
							</div>
							<div class="extra content">
								<div class="ui button troca" id="'.$cod_prod.'">Adicionar</div>
								<input type="hidden" value="0" id="input'.$cod_prod.'" name="cod_'.$cod_prod.'"/>
							</div>
						</div>
				';}
				?>
					</div>
				</div>
				<input type="submit" class="ui fluid large teal submit button bg_secundario" name="lista_finalizada" value="Finalizar">
				<div class="one wide column "></div>
			</div>
		</div>
</form>
<?php 
//include "footer.php"; 
}else{
	header('location: ../views/usuario_login.php');
}
?>