<?php
session_start();
require __DIR__ . "/../conexao/Connection.php";
require __DIR__ . "/../models/Lista.php";


function salvar_lista(){
	if (isset($_POST['lista_finalizada'])) {

		$nome_lista = $_POST['nome_lista'];
		$produtos_selecionados=[];
		$dadosLista = $_POST;
		unset($dadosLista['nome_lista']);
		unset($dadosLista['lista_finalizada']);
        $lista = new Lista();

        foreach ($dadosLista as $key => $value) {
            if ($value==1 and !is_null($value) and !is_null($key)) {
                $cod = explode("cod_", $key);
                $qtdItem = $dadosLista['qtd_item_'.$cod[1]];
                $produtos_selecionados[$cod[1]] = $qtdItem;
            }
            unset($produtos_selecionados[null]);
        }
        $lista->salvar_item_lista($produtos_selecionados,$nome_lista);
        header('location: ../views/usuario_pagina.php');
    }
}






















if (isset($_GET['acao']) and function_exists($_GET['acao'])) {
    call_user_func($_GET['acao']);
}