<?php
if (isset($_GET['acao']) and function_exists($_GET['acao']) ){
    call_user_func($_GET['acao']);
}
require __DIR__."/app/views/home.php";
require __DIR__."semantic/dist/semantic.min.css";

?>
x