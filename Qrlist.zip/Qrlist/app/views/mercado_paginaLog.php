<?php
session_start();
require __DIR__.'/../controllers/produto.php';
if (isset($_SESSION['logado']) and $_SESSION['logado'] = "sim") {
if (isset($_SESSION['mercado']['logado']) and $_SESSION['mercado']['logado'] = "sim") {
require __DIR__.'/cabecalho_geral.php';
?>

<body>

	<div class="ui width grid">
		<div class="one wide column "></div>
		<div class="fourteen wide column">

        <div class="ui middle aligned divided list marginUsu">
        <div class="item">
          <div class="right floated content">
            <div class="ui button">Editar</div>
          </div>
          <div class="header"><h3><?php echo $_SESSION['mercado']['nome_mercado']?></h3></div>
          <div class="ui horizontal bulleted list">
            <div class="item"><?php echo $_SESSION['mercado']['cnpj']?></div>
            <div class="item"><?php echo $_SESSION['mercado']['exif_thumbnail(filename)_mercado']?></div>
            <div class="item"><?php echo $_SESSION['mercado']['telefone_mercado']?></div>
            <div class="item"><?php echo $_SESSION['mercado']['ie']?></div>
          </div>
        </div>
      </div>

			<section class="novaLista margin">
                <a href="mercado.php?acao=mercado_deslogar">
                    <button class="ui primary button direita">Deslogar</button>
                </a>
			</section>
            <?php
            if (isset($_GET['atualizado']) and $_GET['atualizado'] == 'sim'){
                echo '
            <div class="ui horizontal  cor_tercearia">
                Foi
            </div>
            <?php
            ';}elseif(isset($_GET['atualizado']) and $_GET['atualizado'] == 'nao'){
            echo '   
            ?>
             <div class="ui horizontal  cor_tercearia">
                nao Foi
            </div>
            <?php
            ';}
            ?>
			<div class="ui horizontal divider cor_tercearia">
				meus produtos
			</div>

      <a href="../views/produto_cadastro.php"><button class="ui primary button direita">+ Novo produto</button></a>

<?php
    $conexaos = new Connection();
    $recebeConexao = $conexaos->conectar();
    $sql_produtos = "select nome_produto,foto_produto,preco_prod,cod_produto from produtos,mercado where cnpj_prod = cnpj and cnpj = '{$_SESSION['mercado']['cnpj']}';";
    var_dump($sql_produtos);
    $produto = $recebeConexao->query($sql_produtos)->fetchAll(PDO::FETCH_ASSOC);
    var_dump($produto);

foreach ($produto as $key => $value) {
echo '
			<div class="cardMercado margin">
				<div class="ui card">
					<div class="content">
						<div class="header"></div>
					</div>
					<div class="content">
						<img class="img_mercado" src="../../imagens/">
						
            <div class="ui sub header">
              <span class="right floated">
                R$
              </span>
              <span class= "floated">
                n sei o que colocar
              </span>
            </div>

					</div>
          <div class="extra content">
            <button class="ui right floated button">Editar</button>
            <button class="ui left button">Excluir</button>
          </div>
				</div>
			</div>
';
//}
?>



		</div>
		<div class="one wide column "></div>
	</div>

</body>
<?php
include "footer.php";
}else{
  header('location: mercado_login.php');
}
}else{
  header('location: usuario_login.php');
}