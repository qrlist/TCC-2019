<?php
require __DIR__."/../conexao/Connection.php";

require __DIR__."/../models/Usuario.php";

function cabecalho(){
    require __DIR__."/../views/cabecalho.php";
}

function index(){
    //require __DIR__."/../views/cabecalho.php";
    require __DIR__."/../views/usuario_pagina.php";
}

function cadastrar_usuario(){
    require __DIR__."/../views/usuario_cadastro.php";
}

function login_page(){
    require __DIR__ . "/../views/usuario_login.php";
}

function pagina_usuario(){
    require __DIR__ . "/../views/usuario_pagina.php";
}

function getConexao(){
    $conexaos = new Connection();
    $recebeConexao = $conexaos->conectar();
    return $recebeConexao;

}
function usuario_cadastro(){
    $conexaoCadastro = getConexao();
    $primeiro_nome = filter_input(INPUT_POST, 'primeiro_nome', FILTER_SANITIZE_SPECIAL_CHARS);
    $sobrenome = $_POST['sobrenome'];
    $cpf = $_POST['cpf'];
    $telefone = $_POST['telefone'];
    $email = $_POST['email'];
    $senha = MD5($_POST['senha']);
    //var_dump($primeiro_nome);
    $sql_consulta = 'select cpf from usuario';
    $dados = $conexaoCadastro->query($sql_consulta)->fetch(PDO::FETCH_ASSOC);
    $user = new Usuario();
    $user->salvar_usuario($primeiro_nome, $telefone, $sobrenome, $senha, $cpf, $email);
    var_dump($user);
    pagina_usuario();
}

function usuario_login(){
    $conexaoLogin = getConexao();
    $user = new Usuario();
    if( isset($_POST['entrar']) ) {
        $email = $_POST['email_login'];
        $senha = $_POST['senha_login'];
        $query = "select cpf,senha, email  from usuario where email = '{$email}'";
        $dados = $conexaoLogin->query($query);
        if ($dados->rowCount()>0) {
            $dadosUsuario=$dados->fetch(PDO::FETCH_ASSOC);
            $senhaRetornada = $dadosUsuario['senha'];
            if(MD5($senha) == $senhaRetornada) {
                try{
                    $query = "select * from usuario where email = '{$dadosUsuario['email']}' and senha = '{$dadosUsuario['senha']}' and cpf = '{$dadosUsuario['cpf']}'";
                    $dadosRetornados = $conexaoLogin->query($query)->fetch(PDO::FETCH_ASSOC);
                    if(!isset($_SESSION)){
                        session_start();
                    }
                    if (isset($dadosRetornados['cpf'])) {
                        $_SESSION['logado'] = "sim";
                        $_SESSION['cpf'] = $dadosRetornados['cpf'];
                        var_dump($_SESSION);
                        pagina_usuario();
                    }else{
                        $_SESSION['logado'] = "não";
                    }


                }catch (Exception $e){
                    echo 'Error: ',  $e->getMessage(), "oidoiaodiwoidaoidoaw";
                }
            }
        }
    }
    else{
        echo '12345';
    }
}


function usuario_delete(){
    $user = new Usuario();
    var_dump($_SESSION);
    $cpf = $_SESSION['0']['cpf'];
    $user->delete($cpf);
    index();
}

function usuario_deslogar(){
    session_start();
    session_destroy();
    index();
}

/*
if (isset($_GET['acao']) and function_exists($_GET['acao']) ){
    call_user_func($_GET['acao']);
}else {
    index();
}
*/
