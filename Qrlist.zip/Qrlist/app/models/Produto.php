<?php
/**
 * Created by PhpStorm.
 * User: Luiza Farias
 * Date: 18/10/2019
 * Time: 14:30
 */

class Produto{


    public $desc_prod;
    public $peso_liq;
    public $nome_produto;
    public $preco_prod;
    public $foto_produto;
    public $qtd_item_est;
    public $cod_produto;
    public $cod_cat_cod;
    public $marca;

    public $tipoUsuario;

    public $conexao_produto;
//
//
    //COMPORTAMENTOS
    public function __construct(){
        $this->tipoUsuario = 4;
        $conexao_objeto = new Connection();
        $this->conexao_produto= $conexao_objeto->conectar();
    }


    public function salvar_produto($desc_prod, $peso_liq, $nome_produto, $preco_prod, $marca, $cod_cat_cod, $nome_foto_produto,$cnpj_merc){
        $sql_produto = "insert into produtos(desc_prod, peso_liq, nome_produto, preco_prod, foto_produto, marca, cod_cat_cod,cnpj_prod) values ('{$desc_prod}', '{$peso_liq}', '{$nome_produto}', '{$preco_prod}', '{$nome_foto_produto}', '{$cod_cat_cod}' , '{$marca}', '{$cnpj_merc}');";
        $this->conexao_produto->exec($sql_produto);


    }

    public function valida_imagem($foto_produto){

        if ($foto_produto['type'] == 'image/png' or $foto_produto['type'] == 'image/jpeg' ){

            if ($foto_produto['size'] > 400000000000){
                return 2; //ESCOLHA UMA IMAGEM MENOR
            }else{
                return 1; //IMAGEM VALIDA
            }

        }elseif ($foto_produto['type'] == 'image/jpg'){

            if ($foto_produto['size'] > 400000000000){
                return 2; //ESCOLHA UMA IMAGEM MENOR
            }else{
                return 1; //IMAGEM VALIDA
            }

        }elseif (empty($foto_produto['name'])){
            return 4; //SEM IMAGEM
        }else{
            $nome = explode('.', $foto_produto['name']);
            return $nome[1]; //ESCOLHA UMA IMAGEM VALIDA
        }

    }

}