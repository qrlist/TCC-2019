<?php
require __DIR__.'/cabecalho.php';
require __DIR__.'/cabecalho_geral.php';
require __DIR__.'/../controllers/mercado.php';

								 $conexaos = new Connection();
                                 $recebeConexao = $conexaos->conectar();
                                 $sql_uf = "select * from uf order by nome_uf asc ";
                                 $uf = $recebeConexao->query($sql_uf)->fetch(PDO::FETCH_ASSOC);
                                var_dump($uf);
                                foreach($uf as $estados){
                                    echo '<input type="text" name="'.$estados['cod_uf'].'">'.$estados['nome_uf'].'</input>';
                                }