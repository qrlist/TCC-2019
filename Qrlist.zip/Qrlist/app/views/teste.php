<DOCTYPE html>
<html>
<head>
<meta charset="UTF-8"/>
    <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.0.min.js"></script>
    <script type="text/javascript">
    $(document).ready(function () {
    	$( "#target" ).click(function() {
        $(".oi").replaceWith("<h4>Novo conteúdo</h4>");
        });
    })
    </script>
</head>
<body>
	<input type="button" name="target" id="target">
    <h3>Lista de itens</h3>
    <ul class="oi">
        <li>Primeiro item</li>
        <li>Segundo item</li>
        <li>Terceiro item</li>
    </ul>
</body>
</html>
