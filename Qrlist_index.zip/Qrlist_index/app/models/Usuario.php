<?php

class Usuario {

    //ATRIBUTOS DA CLASSE
    public $cpf;
    public $primeiro_nome;
    public $sobrenome;
    public $telefone;
    public $email;
    public $senha;
    public $tipoUsuario; //1 para comum e 2 para admin

    public $conexao_usuario;

    //COMPORTAMENTOS
    public function __construct(){
        $this->tipoUsuario = 1;
        $conexao_objeto = new Connection();
        $this->conexao_usuario = $conexao_objeto->conectar();
    }

    public function salvar_usuario($primeiro_nome, $telefone, $sobrenome, $senha, $cpf, $email){
        $sql_resultado = "insert into usuario(primeiro_nome, telefone, sobrenome, senha, cpf, email, cod_tip_usu_cod) values ('{$primeiro_nome}', '{$telefone}', '{$sobrenome}', '{$senha}', '{$cpf}', '{$email}', 1)";
        $resultado_usuario = $this->conexao_usuario->exec($sql_resultado);
        return $resultado_usuario;
    }

    public function delete($cpf){
        $sql_delete = "delete from usuario where cpf = '{$cpf}'";
        $this->conexao_usuario->exec($sql_delete);
    }
}