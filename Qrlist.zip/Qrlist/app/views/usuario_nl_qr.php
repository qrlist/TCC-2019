<?php
session_start();
include "cabecalho_geral.php";
require __DIR__.'/../controllers/usuario.php';
if (isset($_SESSION['logado']) and $_SESSION['logado'] =='sim'){
    ?>

    <form method="post" action="../controllers/lista.php?acao=salvar_lista">
        <div class="ui width grid">
            <div class="one wide column "></div>
            <div class="fourteen wide column">

                <div class="margin criarNovaLista">
                    <center><h1>Criando Nova Lista</h1>
                        <p>Escaneie todos os produtos que você deseja adicionar a lista, clicando no botão depois salve-a clicando em "Finalizar".</p>
                    </center>
                </div>

                <div class=" margin">
                    <div class="ui horizontal divider">
                        adicione produtos
                    </div>
                </div>


                <video id="preview"></video>
                <input type="number" id="qtd" name="qtd_item" value="1" max = "100" min="1" title="Escolha uma quantidade de produtos que deseja" required="Você precisa adicionar um produto no minímo" /> 
                <script>
                    var cod;
                    var qtd;
                    var scanner = new Instascan.Scanner(
                        {
                            video: document.getElementById('preview')
                        }
                    );
                    scanner.addListener('scan', function(content) {
                        alert('Um produto foi escaneado');
                        cod = document.getElementById('cod');
                        qtd = document.getElementById('qtd');
                        var value = qtd.value;
                        cod.href = "../controllers/lista.php?acao=lista_qr&&cod_produto="+ content +"&&qtd="+ value;
                    });

                    Instascan.Camera.getCameras().then(function (cameras) {
                        if (cameras.length > 0) {
                            scanner.start(cameras[0]);
                        } else {
                            alert('Não foi encontrada nenhuma camera.');
                        }
                    }).catch(function (e) {
                        console.error(e);
                    });
                </script>
        
        <a href="" id="cod">
        <input type="button" class="ui fluid large teal submit button" name="add_prod" value="Adiconar">
        </a>
        <input type="submit" class="ui fluid large teal submit button bg_secundario" name="lista_finalizada" value="Finalizar">
        <div class="one wide column "></div>
        </div>
        </div>
    </form>
    <?php
//include "footer.php";
}else{
    header('location: ../views/usuario_login.php');
}
?>














