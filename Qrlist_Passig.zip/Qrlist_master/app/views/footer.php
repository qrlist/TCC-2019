</body>
<footer >
 <div class="ui inverted vertical footer segment">
                <div class="ui container">
                    <div class="ui stackable inverted divided equal height stackable grid">
                        <div class="three wide column">
                            <h4 class="ui inverted header">About</h4>
                            <div class="ui inverted link list">
                                <a href="../views/usuario_nl.php" class="item">Criar lista</a>
                                <a href="../views/usuario_editar.php" class="item">Editar usuario</a>
                                <a href="../views/mercado_login.php" class="item">Mercado Login</a>
                                <a href="#" class="item">Gazebo Plans</a>
                            </div>
                        </div>
                        <div class="three wide column">
                            <h4 class="ui inverted header">Serviços </h4>
                            <div class="ui inverted link list">
                                <a href="../views/login.php" class="item">Login</a>
                                <a href="../views/usuario_cadastro.php" class="item">Cadastro Usuario</a>
                                <a href="../views/home.php" class="item">Página inicial</a>
                                <a href="../views/usuario_pagina.php" class="item">Pagina Usuario</a>
                            </div>
                        </div>
                        <div class="seven wide column">
                            <h4 class="ui inverted header">Deseja fazer parte do QrList?</h4>
                            <p>Se você é dono de mercado e deseja participar da comunidade QrList, cadastre seu mercado <a href="   mercado_cadastro.php">aqui</a>!</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
</footer>
</html>