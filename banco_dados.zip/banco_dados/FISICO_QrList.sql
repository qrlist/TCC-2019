-- Gera��o de Modelo f�sico
-- Sql ANSI 2003 - brModelo.



CREATE TABLE tipo_usu (
desc_tip_usu varchar(20) not null,
cod_tip_usu int(3) auto_increment not null PRIMARY KEY
);

CREATE TABLE usuario (
primeiro_nome varchar(50) not null,
telefone char(13) not null,
cpf char(11) not null PRIMARY KEY,
sobrenome varchar(50) not null,
email varchar(60) not null,
senha varchar(50) not null,
cod_tip_usu_cod int(3) not null,
FOREIGN KEY(cod_tip_usu_cod) REFERENCES tipo_usu (cod_tip_usu)
);

CREATE TABLE lista (
cod_lista int(3) auto_increment not null PRIMARY KEY,
valor_lista varchar(60) not null,
cpf char(11) not null,
FOREIGN KEY(cpf) REFERENCES usuario (cpf)
);

CREATE TABLE produtos (
desc_prod varchar(800) not null,
peso_liq varchar(10) not null,
nome_produto varchar(200) not null,
preco_prod float(6,2) not null,
foto_produto varchar(300) not null,
qtd_item_est int(10) not null,
marca varchar(80) not null,
cod_produto int(3) auto_increment not null PRIMARY KEY,
cod_cat_cod int(5) not null
);

CREATE TABLE tipo_end (
desc_tipo_end varchar(80),
cod_tipo_end int(3) PRIMARY KEY
);

CREATE TABLE endereco (
cod_end int(3) auto_increment not null PRIMARY KEY,
rua varchar(50) not null,
numero int(6) not null,
cod_bairro int(3) not null,
cod_tipo_end int(3) not null,
cpf char(11) not null,
FOREIGN KEY(cod_tipo_end) REFERENCES tipo_end (cod_tipo_end),
FOREIGN KEY(cpf) REFERENCES usuario (cpf)
);

CREATE TABLE cidade (
nome_cidade varchar(80) not null,
cod_cidade int(3) auto_increment not null PRIMARY KEY,
cod_uf int(3) not null
);

CREATE TABLE uf (
cod_uf int(3) auto_increment not null PRIMARY KEY,
nome_uf varchar(80) not null
);

CREATE TABLE endereco_mercado (
cnpj char(18) not null,
cod_end int(3) not null,
FOREIGN KEY(cod_end) REFERENCES endereco (cod_end)
);

CREATE TABLE mercado (
nome_mercado varchar(500) not null,
cnpj char(18) not null PRIMARY KEY,
senha_mercado varchar(100) not null,
ie char(11) not null,
email_mercado varchar(150) not null,
telefone_mercado varchar(13) not null
);

CREATE TABLE produto_mercado (
cod_produto int(3) not null,
cnpj char(18) not null,
FOREIGN KEY(cod_produto) REFERENCES produtos (cod_produto),
FOREIGN KEY(cnpj) REFERENCES mercado (cnpj)
);

CREATE TABLE bairro (
nome_bairro varchar(80) not null,
cod_bairro int(3) auto_increment not null PRIMARY KEY,
cod_cidade int(3) not null,
FOREIGN KEY(cod_cidade) REFERENCES cidade (cod_cidade)
);

CREATE TABLE categoria_prod (
cod_cat int(5) auto_increment not null PRIMARY KEY,
nome_cat varchar(50) not null
);

CREATE TABLE item_lista (
cod_produto_cod int(3) not null,
cod_lista_cod int(3) not null,
cod_tem_lista int(3) auto_increment not null PRIMARY KEY,
qtd_item_lista int(10) not null,
FOREIGN KEY(cod_produto_cod) REFERENCES produtos (cod_produto),
FOREIGN KEY(cod_lista_cod) REFERENCES lista (cod_lista)
);

ALTER TABLE produtos ADD FOREIGN KEY(cod_cat_cod) REFERENCES categoria_prod (cod_cat);
ALTER TABLE endereco ADD FOREIGN KEY(cod_bairro) REFERENCES bairro (cod_bairro);
ALTER TABLE cidade ADD FOREIGN KEY(cod_uf) REFERENCES uf (cod_uf);
ALTER TABLE endereco_mercado ADD FOREIGN KEY(cnpj) REFERENCES mercado (cnpj);
