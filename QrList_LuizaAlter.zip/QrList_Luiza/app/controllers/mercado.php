<?php

require __DIR__."/../conexao/Connection.php";
require __DIR__."/../models/Mercado.php";

function cabecalho(){
    require __DIR__."/../views/cabecalho.php";
}

function index(){
    require __DIR__."/../views/home.php";
}

if (isset($_GET['acao']) and function_exists($_GET['acao']) ){
    call_user_func($_GET['acao']);
}


function marcado_cadastro(){

        $conexaoCadastroMercado = getConexao();
        $nome_mercado = filter_input(INPUT_POST, 'nome_mercado', FILTER_SANITIZE_SPECIAL_CHARS);
        $senha_mercado = MD5($_POST['senha']);
        $cnpj = $_POST['cnpj'];
        //FAZER VERIFICAÇÃO
        $ie = $_POST['ie'];
        $email_mercado = $_POST['email_mercado'];
        $telefone_mercado = $_POST['telefone_mercado'];
        //$foto_mercado RESOLVER
        $rua = $_POST['rua'];
        $numero = $_POST['numero'];
        $cep = $_POST['cep'];
        $sql_cnpj = "select cnpj from mercado where cnpj = '{$cnpj}'";
        $dados['cnpj'] = $conexaoCadastroMercado->query($sql_cnpj)->fetch(PDO::FETCH_ASSOC);
        $sql_email = "select email from mercado where email = '{$email}'";
        $dados['email'] = $conexaoCadastroMercado->query($sql_email)->fetch(PDO::FETCH_ASSOC);
        if ($dados['cnpj'] != false) {
            header('location: ../views/mercado_cadastro.php?error=cnpj');
        }elseif($dados['email'] !=false){
            header('location: ../views/mercado_cadastro.php?error=email');
        }elseif (empty($dados['cnpj']) and empty($dados['email']) ){

            $mercado = new Mercado();
            $mercado->salvar_mercado($nome_mercado, $senha_mercado, $cnpj, $ie, $email_mercado, $telefone_mercado, $rua, $numero, $cep);
            //vai ser criado
            //pagina_login_mercado();
        }

        //falta fazer o select
}

