<?php
session_start();
if (isset($_SESSION['logado']) and $_SESSION['logado'] == 'sim'){
  require __DIR__.'/cabecalho_geral.php';
  ?>

  <body>

   <div class="ui width grid">
    <div class="one wide column "></div>
    <div class="fourteen wide column">

      <div class="ui middle aligned divided list marginUsu">
        <div class="item">
          <div class="right floated content">
            <a href="usuario_editar.php"><div class="ui button">Editar</div></a>
      
             <?php

             ?>
           </div>
           <div class="header"><h3><?php echo $_SESSION['primeiro_nome'].' '.$_SESSION['sobrenome']; ?></h3></div>
           <div class="ui horizontal bulleted list">
            <div class="item"><?php echo $_SESSION['email'] ?>;</div>
            <div class="item"><?php echo $_SESSION['cpf'] ?></div>
            <div class="item"><?php echo $_SESSION['telefone']; ?></div>
          </div>
        </div>
      </div>

          <div class="ui horizontal divider cor_tercearia">
            Minhas listas
          </div>

          <a href="usuario_nl.php"><button class="ui primary button direita">+ Nova lista</button></a>

<!--
//              $conexaos = new Connection();
//              $recebeConexao = $conexaos->conectar();
//              $sql_produtos = "select distinct nome_lista,foto_produto,preco_prod,cod_produto,marca,nome_cat,desc_prod, peso_liq from produtos,mercado,categoria_prod where cnpj_prod = cnpj and cnpj = '{$_SESSION['mercado']['cnpj']}' and cod_cat_cod = cod_cat;";
//              $produto = $recebeConexao->query($sql_produtos)->fetchAll(PDO::FETCH_ASSOC);
-->





          <div class="cardMercado margin">
            <div class="ui card">
             <div class="content">
              <div class="header">Nome da Lista</div>
            </div>
            <div class="content">
              <img class="img_mercado" src="../../imagens/index.jpg">
              <div class="ui sub header">
                <span class="right floated">
                  R$23,87
                </span>
                <span class= "floated">
                  21/10/2019
                </span>
              </div>

            </div>
            <div class="extra content">
              <button class="ui right floated button">Editar</button>
              <button class="ui left button">Excluir</button>
            </div>
          </div>

        </div>

      </div>
      <div class="one wide column "></div>
    </div>

  </body>
  <?php
  include 'footer.php';
}else{
 header('location: ../views/usuario_login.php');
}