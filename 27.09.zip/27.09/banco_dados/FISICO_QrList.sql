-- Gera��o de Modelo f�sico
-- Sql ANSI 2003 - brModelo.



CREATE TABLE tipo_usu (
desc_tip_usu varchar(20) not null,
cod_tip_usu int(3) auto_increment not null PRIMARY KEY
);

CREATE TABLE usuario (
primeiro_nome varchar(50) not null,
telefone char(13) not null,
sobrenome varchar(50) not null,
senha varchar(50) not null,
cpf char(14) not null PRIMARY KEY,
email varchar(60) not null,
cod_tip_usu_cod int(3) not null,
FOREIGN KEY(cod_tip_usu_cod) REFERENCES tipo_usu (cod_tip_usu)
);

CREATE TABLE lista (
cod_lista int(3) auto_increment not null PRIMARY KEY,
valor_lista varchar(60) not null,
cpf char(14) not null,
FOREIGN KEY(cpf) REFERENCES usuario (cpf)
);

CREATE TABLE item_lista (
cod_produto int(3) not null,
cod_lista int(3) not null,
cod_tem_lista int(3) auto_increment not null PRIMARY KEY,
qtd_item_lista int(10) not null,
FOREIGN KEY(cod_lista) REFERENCES lista (cod_lista)
);

CREATE TABLE endereco (
cod_end int(3) auto_increment not null PRIMARY KEY,
rua varchar(50) not null,
numero int(6) not null,
cpf char(14) not null,
cod_bairro int(3) not null,
cnpj int(14) not null,
cod_tipo_end int(3) not null,
FOREIGN KEY(cpf) REFERENCES usuario (cpf)
);

CREATE TABLE mercado (
nome_mercado varchar(80) not null,
foto_mercado varchar(300) not null,
cnpj int(14) not null PRIMARY KEY
);

CREATE TABLE tipo_end (
desc_tipo_end varchar(80) not null,
cod_tipo_end int(3) auto_increment not null PRIMARY KEY
);

CREATE TABLE bairro (
nome_bairro varchar(80) not null,
cod_bairro int(3) auto_increment not null PRIMARY KEY,
cod_cidade int(3) not null
);

CREATE TABLE produtos_mercado (
cod_produto int(3) not null,
cnpj int(14) not null,
FOREIGN KEY(cnpj) REFERENCES mercado (cnpj)
);

CREATE TABLE cidade (
nome_cidade varchar(80) not null,
cod_cidade int(3) auto_increment not null PRIMARY KEY,
cod_uf int(3) not null
);

CREATE TABLE produtos (
peso_liq varchar(10) not null,
qtd_item_est int(10) not null,
marca varchar(80) not null,
foto_produto varchar(300) not null,
nome_produto varchar(200) not null,
desc_prod varchar(800) not null,
preco_prod float(6,2) not null,
cod_produto int(3) auto_increment not null PRIMARY KEY,
cod_cat_cod int(5) not null
);

CREATE TABLE categoria_prod (
cod_cat int(5) auto_increment not null PRIMARY KEY,
nome_cat varchar(50) not null
);

CREATE TABLE uf (
cod_uf int(3) auto_increment not null PRIMARY KEY,
nome_uf varchar(80) not null
);

ALTER TABLE item_lista ADD FOREIGN KEY(cod_produto) REFERENCES produtos (cod_produto);
ALTER TABLE endereco ADD FOREIGN KEY(cod_bairro) REFERENCES bairro (cod_bairro);
ALTER TABLE endereco ADD FOREIGN KEY(cnpj) REFERENCES mercado (cnpj);
ALTER TABLE endereco ADD FOREIGN KEY(cod_tipo_end) REFERENCES tipo_end (cod_tipo_end);
ALTER TABLE bairro ADD FOREIGN KEY(cod_cidade) REFERENCES cidade (cod_cidade);
ALTER TABLE produtos_mercado ADD FOREIGN KEY(cod_produto) REFERENCES produtos (cod_produto);
ALTER TABLE cidade ADD FOREIGN KEY(cod_uf) REFERENCES uf (cod_uf);
ALTER TABLE produtos ADD FOREIGN KEY(cod_cat_cod) REFERENCES categoria_prod (cod_cat);

INSERT INTO `uf` (`cod_uf`, `nome_uf`) VALUES (NULL, 'SC');
INSERT INTO `tipo_usu` (`desc_tip_usu`, `cod_tip_usu`) VALUES ('Comum', NULL), ('Admin', NULL), ('Mercado', NULL);
INSERT INTO `tipo_end` (`desc_tipo_end`, `cod_tipo_end`) VALUES ('Comum', NULL), ('Mercado', NULL);
INSERT INTO `cidade` (`nome_cidade`, `cod_cidade`, `cod_uf`) VALUES ('Joinville', NULL, '1');
INSERT INTO `bairro` (`nome_bairro`, `cod_bairro`, `cod_cidade`) VALUES ('Profipo', NULL, '1');

