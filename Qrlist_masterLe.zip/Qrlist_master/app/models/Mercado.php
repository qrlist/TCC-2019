<?php

class Mercado{

    //ATRIBUTOS DA CLASSE
    public $nome_mercado;
    public $cnpj;
    public $senha_mercado;
    public $ie;
    public $email_mercado;
    public $telefone_mercado;
    public $rua;
    public $numero;
    public $cep;
    public $tipoUsuario;

    public $conexao_mercado;

    public function __construct(){
        $this->tipoUsuario = 3;
        $conexao_objeto = new Connection();
        $this->conexao_mercado = $conexao_objeto->conectar();
    }

    public function salvar_mercado($nome_mercado, $senha_mercado, $cnpj, $ie, $email_mercado, $telefone_mercado, $rua, $numero, $cep){
        $sql_mercado = "insert into mercado(nome_mercado, senha_mercado, cnpj, ie, email_mercado, telefone_mercado, cod_tip_usu_cod) values ('{$nome_mercado}', '{$senha_mercado}', '{$cnpj}', '{$ie}', '{$email_mercado}', '{$telefone_mercado}', 3)";
        $this->conexao_mercado->exec($sql_mercado);

//        $sql_mercado_endereco = "insert into endereco(rua, numero, cep) values ('{$rua}', '{$numero}', {$cep})";
//        $this->conexao_mercado->exec($sql_mercado_endereco);
    }

}