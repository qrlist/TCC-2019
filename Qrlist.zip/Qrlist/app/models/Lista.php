<?php
/**
 * Created by PhpStorm.
 * User: Luiza Farias
 * Date: 24/10/2019
 * Time: 15:32
 */

class Lista{

    public $cod_lista;
    public $valor_lista;
    public $cpf_lista;

    public $tipoUsuario;

    public $conexao_lista;


    public function __construct(){
        $this->tipoUsuario = 5;
        $conexao_objeto = new Connection();
        $this->conexao_lista= $conexao_objeto->conectar();
    }

    public function salvar_item_lista($produtos_selecionados,$nome_lista){
        $cpf_lista = $_SESSION['cpf'];
        $sql_lista = "insert into lista(valor_lista,nome_lista,cpf_lista) values(0,'{$nome_lista}','{$cpf_lista}');";
        $this->conexao_lista->exec($sql_lista);

        $sql_consulta = "select distinct cod_lista from lista,usuario where cpf_lista = '{$_SESSION['cpf']}' and nome_lista = '{$nome_lista}';";
        $cod_lista = $this->conexao_lista->query($sql_consulta)->fetch(PDO::FETCH_ASSOC);

        foreach ($produtos_selecionados as $linha => $valor){
            $sql_item_lista = "insert into item_lista(cod_produto_cod,cod_lista_cod,qtd_item_lista) values ('{$linha}','{$cod_lista['cod_lista']}','{$valor}');";
            $this->conexao_lista->exec($sql_item_lista);
        }


        $sql_cods = "select distinct cod_produto_cod from item_lista,lista,produtos,usuario where cpf_lista = cpf and cpf = '{$_SESSION['cpf']}' and cod_lista_cod = cod_lista and cod_lista = '{$cod_lista['cod_lista']}' and nome_lista = '{$nome_lista}';";
        $cods = $this->conexao_lista->query($sql_cods)->fetchAll(PDO::FETCH_ASSOC);


        foreach ($cods as $prod_selec => $array){
            foreach ($array as $key => $cod) {

                $sql_qtd = "select distinct qtd_item_lista from item_lista,lista,produtos,usuario where cpf_lista = cpf and cpf = '{$_SESSION['cpf']}' and cod_lista_cod = cod_lista and cod_lista = '{$cod_lista['cod_lista']}' and nome_lista = '{$nome_lista}' and cod_produto_cod = cod_produto and cod_produto = '{$cod}';";
                $qtds = $this->conexao_lista->query($sql_qtd)->fetchAll(PDO::FETCH_ASSOC);
                $sql_preco_unit = "select preco_prod from produtos where cod_produto = '{$cod}';";
                $precos_unit = $this->conexao_lista->query($sql_preco_unit)->fetchAll(PDO::FETCH_ASSOC);
                print_r($preco_unit);

                foreach ($qtds as $key => $array){
                    foreach ($array as $key => $qtd) {


                    }
                }

                foreach ($precos_unit as $key => $array){
                    foreach ($array as $key => $preco) {

                    }
                }

                $cod_all[] = $cod;
                $qtd_all[] = $qtd;
                $preco_all[] = $preco;
                $preco_total = array_sum($preco_all);

            }
            $preco_mult = $qtd_all[$prod_selec] * $preco_all[$prod_selec];
            $preco_multiplicado[] = $preco_mult;
            $preco_multiplicado_s = array_sum($preco_multiplicado);
        }

        $sql_update_preco = "UPDATE lista SET valor_lista = '{$preco_multiplicado_s}' WHERE cod_lista = {$cod_lista['cod_lista']};";
        $this->conexao_lista->exec($sql_update_preco);

    }

}