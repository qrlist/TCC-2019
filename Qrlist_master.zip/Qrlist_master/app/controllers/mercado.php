<?php

require __DIR__."/../conexao/Connection.php";
require __DIR__."/../models/Mercado.php";

function cabecalho(){
    require __DIR__."/../views/cabecalho.php";
}

function index(){
    require __DIR__."/../views/home.php";
}

function pagina_mercado_login(){
    require __DIR__.'/../views/mercado_login.php';
}

if (isset($_GET['acao']) and function_exists($_GET['acao']) ){
    call_user_func($_GET['acao']);
}

function getConexao(){
    $conexaos = new Connection();
    $recebeConexao = $conexaos->conectar();
    return $recebeConexao;

}

function seleciona_uf(){
    $conexaoSelectMercado = getConexao();
    $sql_uf = "select * from uf ";
    $dados['uf'] = $conexaoSelectMercado->query($sql_uf)->fetch(PDO::FETCH_ASSOC);
    return $dados['uf'];
//    var_dump($dados['uf']);

}

function seleciona_cidade($cod_uf){
    $conexaoSelectMercado = getConexao();
    $sql_cidade = "select * from cidade where cod_uf_cod = '{$cod_uf}' ";
    $dados['cidade'] = $conexaoSelectMercado->query($sql_cidade)->fetch(PDO::FETCH_ASSOC);
//    var_dump($dados['cidade']);

}

function seleciona_bairro($cod_uf, $cod_cidade){
    $conexaoSelectMercado = getConexao();
    $sql_bairro = "select * from bairro where cod_uf_cod = '{$cod_uf}' and cod_cidade_cod = '{$cod_cidade}' ";
    $dados['bairro'] = $conexaoSelectMercado->query($sql_bairro)->fetch(PDO::FETCH_ASSOC);
//    var_dump($dados['bairro']);

}

function mercado_cadastro(){
if (isset($_POST['cadastrar_mercado'])) {
    $conexaoCadastroMercado = getConexao();
    $nome_mercado = filter_input(INPUT_POST, 'nome_mercado', FILTER_SANITIZE_SPECIAL_CHARS);
    $cnpj = $_POST['cnpj'];
    $senha_mercado = MD5($_POST['senha_mercado']);
    $ie = $_POST['ie'];
    $email_mercado = $_POST['email_mercado'];
    $telefone_mercado = $_POST['telefone_mercado'];
    $rua = $_POST['rua'];
    $numero = $_POST['numero'];
    $cep = $_POST['cep'];
    var_dump($cnpj);
    $sql_cnpj = "select cnpj from mercado where cnpj = '{$cnpj}'";
    $dados['cnpj'] = $conexaoCadastroMercado->query($sql_cnpj)->fetch(PDO::FETCH_ASSOC);
    $sql_email = "select email_mercado from mercado where email_mercado = '{$email_mercado}'";
    $dados['email_mercado'] = $conexaoCadastroMercado->query($sql_email)->fetch(PDO::FETCH_ASSOC);
    if ($dados['cnpj'] != false) {
        header('location: ../views/mercado_cadastro.php?error=cnpj');
    } elseif ($dados['email_mercado'] != false) {
        header('location: ../views/mercado_cadastro.php?error=email_mercado');
    }elseif ($dados['ie'] != false){
        header('location: ../views/mercado_cadastro.php?error=ie');
    }elseif (empty($dados['cnpj']) and empty($dados['email'])) {
        $mercado = new Mercado();
        $mercado->salvar_mercado($nome_mercado, $senha_mercado, $cnpj, $ie, $email_mercado, $telefone_mercado, $rua, $numero, $cep);
        pagina_mercado_login();
    }
}
}

