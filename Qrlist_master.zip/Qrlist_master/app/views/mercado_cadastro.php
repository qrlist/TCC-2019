<?php
	require __DIR__.'/cabecalho_geral.php';
?>
<body>	

        <div class="ui mobile reversed equal width grid">
          <div class="column"></div>
          <div class="column">

            <div class="marginCadM">
                <h1>
                    <div class="ui horizontal divider">
                        Cadastro de mercado
                    </div>
                </h1>
            </div>

            <form class="ui large form">
			  <div class="ui stacked segment">

			  	 <div class="field">
                  <label>Nome do mercado</label>
                  <input type="text" placeholder="Ex.: Pague Menos">
                </div>

                <div class="field">
                  <label>CNPJ</label>
                  <input type="text" placeholder="Ex.: 22.333.333/4444.22">
                </div>

				<div class="two fields">
				  <div class="field">
				    <label>Rua</label>
				     <input placeholder="Ex.: Das Palmeiras" readonly="" type="text">
				   </div>

				   <div class="field">
				     <label>Número</label>
				     <input placeholder="365" readonly="" type="text">
				   </div>
				 </div>

				  <div class="fields">
				    <div class="seven wide field">
				      <label>Cidade</label>
				      <input type="text" placeholder="Ex.: Bombinhas">
				    </div>

				    <div class="three wide field">
				      <label>UF</label>
				      <input type="text" placeholder="Ex.: SC">
				    </div>

				    <div class="six wide field">
				      <label>Bairro</label>
				      <input type="text" placeholder="Ex.: Bom sucesso">
				    </div>
				  </div>

				<div class="ui fluid large teal submit button bg_secundario">Cadastrar</div>
			  </div>

			</form>
          </div>
          <div class="column"></div>
        </div>


</div>
</div>
</div>
</body>
<?php include "footer.php"  ?>