<html>
<head>
	<!-- Standard Meta -->
	<meta charset="utf-8">

	<!-- Site Properties -->
	<title>QrList</title>
	<link rel="stylesheet" type="text/css" href="../../semantic/dist/semantic.min.css">
	<link rel="stylesheet" type="text/css" href="../../css/style.css">
</head>

<body>

	<?php include "cabecalho_geral.php" ?>

	<div class="ui width grid">
		<div class="one wide column "></div>
		<div class="fourteen wide column">

			<div class="margin criarNovaLista">
				<center><h1>Criando Nova Lista</h1>
					<p>Selecione todos os produtos que você deseja adicionar a lista, depois salve-a clicando em "Finalizar".</p></center>
				</div>

				<div class=" margin">
					<div class="ui horizontal divider"> 
						adicione produtos a sua lista
					</div>
				</div>

				<div class="filtro">
						<div class="ui search centro">
						<div class="ui icon input">
							<input class="prompt" type="text" placeholder="Pesquisar">
							<i class="search icon"></i>
						</div>

						<div class="ui floating labeled icon dropdown button drop direita">
							<i class="filter icon"></i>
							<span class="text">Filter</span>
							<div class="menu">
								<div class="header">
									<i class="tags icon"></i>
									Filtro
								</div>
								<div class="item">Todos os mercados</div>
								<div class="item">Mercado 1</div>
								<div class="item">Mercado 2</div>
							</div>
						</div>
					</div>			
				</div>

				<div class="conteudoNovaLista">
					<div class="cardProduto">
						<div class="ui card">
							<div class="content">
								<div class="header">Margarina Qualy</div>
							</div>
							<div class="content">
								<img class="img_mercado" src="../../imagens/index.jpg">
								<p></p>
								<p class="ui sub header">Peso liquido: 500gr</p>
								<p class="ui sub header">Valor: R$5,50</p>
								<p class="ui sub header">Nome do mercado</p>
							</div>
							<div class="extra content">
								<button class="ui button">Adicionar</button>
							</div>
						</div>
					</div>
				</div>
				
			</div>
			<div class="one wide column "></div>
		</div>

	</body>