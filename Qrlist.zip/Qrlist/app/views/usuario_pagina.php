<?php
session_start();
if (isset($_SESSION['logado']) and $_SESSION['logado'] = 'sim'){
  require __DIR__.'/cabecalho_geral.php';
  ?>

  <body>

   <div class="ui width grid">
    <div class="one wide column "></div>
    <div class="fourteen wide column">

      <div class="ui middle aligned divided list marginUsu">
        <div class="item">
          <div class="right floated content">
            <a href="usuario_editar.php"><div class="ui button">Editar</div></a>
      
             <?php

             ?>
           </div>
           <div class="header"><h3>Nome Usuario</h3></div>
           <div class="ui horizontal bulleted list">
            <div class="item">email@usuario.com</div>
            <div class="item">098.675.251-88</div>
            <div class="item">(47)99645-7629</div>
          </div>
        </div>
      </div>

      <?php
      if (isset($_GET['atualizado']) and $_GET['atualizado'] == 'sim'){
        echo '
        <div class="ui horizontal  cor_tercearia">
        Foi
        </div>
        <?php
        ';}elseif(isset($_GET['atualizado']) and $_GET['atualizado'] == 'nao'){
          echo '   
          ?>
          <div class="ui horizontal  cor_tercearia">
          nao Foi
          </div>
          <?php
          ';}
          ?>
          <div class="ui horizontal divider cor_tercearia">
            Minhas listas
          </div>

          <a href="usuario_nl.php"><button class="ui primary button direita">+ Nova lista</button></a>

          <div class="cardMercado margin">
            <div class="ui card">
             <div class="content">
              <div class="header">Nome da Lista</div>
            </div>
            <div class="content">
              <img class="img_mercado" src="../../imagens/index.jpg">
              <div class="ui sub header">
                <span class="right floated">
                  R$23,87
                </span>
                <span class= "floated">
                  21/10/2019
                </span>
              </div>

            </div>
            <div class="extra content">
              <button class="ui right floated button">Editar</button>
              <button class="ui left button">Excluir</button>
            </div>
          </div>

        </div>

      </div>
      <div class="one wide column "></div>
    </div>

  </body>
  <?php
  include 'footer.php';
}else{
 header('location: ../views/usuario_login.php');
}