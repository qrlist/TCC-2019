<?php
require __DIR__.'../conexao/Connection.php'; 
        $conexaos = new Connection();
        $recebeConexao = $conexaos->conectar();
		$sql_cidade= "select * from cidade,estado where cod_uf=cod_uf_cod and nome_uf='".$_POST['nome_uf']."'";
        $cidade = $recebeConexao->query($sql_cidade)->fetch(PDO::FETCH_ASSOC);
		echo'<option>Cidade</option>';
		foreach ($cidade as $cidades) {
			echo'<option value="'.$cidades['cod_cidade'].'">'.$cidades['nome_cidade'].'</option>';
		}      	
?>


